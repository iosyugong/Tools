//
//  UIButton+LPEnlargeTouchArea.h
//
//
//  Created by liupeng on 2018/4/11.
//  Copyright © 2018年  All rights reserved.
//  扩大UIButton的点击范围

#import <UIKit/UIKit.h>

@interface UIButton (LPEnlargeTouchArea)
/** 四周可点击区域不一样 */
- (void)setEnlargeEdgeWithTop:(CGFloat)top right:(CGFloat)right bottom:(CGFloat)bottom left:(CGFloat)left;
/** 四周可点击区域相同 */
- (void)setEnlargeEdge:(CGFloat)size;

@end
